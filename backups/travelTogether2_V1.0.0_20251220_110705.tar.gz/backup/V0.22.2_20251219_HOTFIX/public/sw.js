// Service Worker for Travel Together PWA
const CACHE_NAME = 'travel-together-v16.2.1';
const urlsToCache = [
    '/',
    '/index.html',
    '/pwa-icon.svg'
];

// Install event - cache core assets
self.addEventListener('install', (event) => {
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then((cache) => {
                console.log('[SW] Opened cache');
                return cache.addAll(urlsToCache);
            })
            .then(() => self.skipWaiting())
    );
});

// Activate event - clean up old caches
self.addEventListener('activate', (event) => {
    event.waitUntil(
        caches.keys().then((cacheNames) => {
            return Promise.all(
                cacheNames.map((cacheName) => {
                    if (cacheName !== CACHE_NAME) {
                        console.log('[SW] Deleting old cache:', cacheName);
                        return caches.delete(cacheName);
                    }
                })
            );
        }).then(() => self.clients.claim())
    );
});

// Fetch event - network first, fallback to cache
self.addEventListener('fetch', (event) => {
    // Skip non-GET requests
    if (event.request.method !== 'GET') return;

    // Skip external URLs except for images
    const url = new URL(event.request.url);
    const isExternal = url.origin !== location.origin;
    const isImage = event.request.destination === 'image';

    if (isExternal && !isImage) return;

    event.respondWith(
        fetch(event.request)
            .then((response) => {
                // Don't cache non-successful responses
                if (!response || response.status !== 200 || response.type !== 'basic') {
                    return response;
                }

                // Clone and cache successful responses
                const responseToCache = response.clone();
                caches.open(CACHE_NAME)
                    .then((cache) => {
                        cache.put(event.request, responseToCache);
                    });

                return response;
            })
            .catch(() => {
                // Fallback to cache when offline
                return caches.match(event.request)
                    .then((cachedResponse) => {
                        // Return cached response or a simple 404 response
                        return cachedResponse || new Response('Not found', { status: 404, statusText: 'Not found' });
                    });
            })
    );
});
