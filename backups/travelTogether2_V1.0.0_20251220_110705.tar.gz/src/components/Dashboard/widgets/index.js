// Dashboard Widgets Index
export { default as WeatherWidget } from './WeatherWidget';
export { default as NewsWidget } from './NewsWidget';
export { default as HotelsWidget } from './HotelsWidget';
export { default as FlightsWidget } from './FlightsWidget';
export { default as TransportWidget } from './TransportWidget';
export { default as ConnectivityWidget } from './ConnectivityWidget';
export { default as CurrencyConverter } from './CurrencyConverter';
