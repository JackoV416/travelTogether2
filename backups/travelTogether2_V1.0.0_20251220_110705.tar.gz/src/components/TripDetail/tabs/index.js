// TripDetail Tabs - Barrel Export
export { default as ItineraryTab } from './ItineraryTab';
export { default as EmergencyTab } from './EmergencyTab';
export { default as InsuranceTab } from './InsuranceTab';
export { default as BudgetTab } from './BudgetTab';
export { default as CurrencyTab } from './CurrencyTab';
export { default as ShoppingTab } from './ShoppingTab';
export { default as PackingTab } from './PackingTab';
export { default as FilesTab } from './FilesTab';
export { default as VisaTab } from './VisaTab';
export { default as JournalTab } from './JournalTab';
export { default as GalleryTab } from './GalleryTab';
